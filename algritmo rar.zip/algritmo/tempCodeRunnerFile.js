const read = require('prompt-sync')();
const whrite = console.log 
function tabla(){

let numero = read("Por favor, ingrese un número:");


for (var i = 1; i <= 10; i++) {
    var resultado = numero * i;
    console.log(numero + " x " + i + " = " + resultado);
}
}
tabla()